#' R2SSUR -- Bayesian Sparse Seemingly Unrelated Regression
#' Check posterior distributions of different parameters, trace & density
#' @export
postDiag <- function(object){
  return(1)
}