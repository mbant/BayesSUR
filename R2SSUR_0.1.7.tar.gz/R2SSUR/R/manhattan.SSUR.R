
#' R2SSUR -- Bayesian Sparse Seemingly Unrelated Regression
#' Manhattan plot
#' @export
manhattan.SSUR <- function(object){
  return(1)
}