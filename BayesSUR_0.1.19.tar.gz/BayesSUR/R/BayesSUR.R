#' BayesSUR -- Bayesian Seemingly Unrelated Regression
#' @title Bayesian Sparse Seemingly Unrelated Regression
#' @docType package
#' @name BayesSUR
#' @importFrom Rcpp sourceCpp
#' @importFrom utils read.table write.table
#' @useDynLib BayesSUR
NULL
