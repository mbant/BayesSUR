#' R2SSUR -- Bayesian Sparse Seemingly Unrelated Regression
#' @title Bayesian Sparse Seemingly Unrelated Regression
#' @docType package
#' @name R2SSUR
#' @importFrom Rcpp sourceCpp
#' @importFrom utils read.table write.table
#' @useDynLib R2SSUR
NULL
