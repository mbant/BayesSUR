# This script contains Roxygen code for the datasets used in BayesSUR

#' @title targetGene
#' @name targetGene
#' @docType data
NULL